#Importado de librerías
import pandas as pd
import numpy as np
import pprint as pp
import random
import sys
import matplotlib.pyplot as plt



#Definición de funciones
def generarBD(indice):
    
    #Colecciones e información base para generar el dataframe
    numeroEstudiantes = 10    
    nombres = [ 'Carlos','Pedro','Juan','Nathalia','Valentina','MariaCamila']
    codigos = ['asjhd7','aksjd8','hh6','898s','uj77f','rtgerg','ref56','jyju8','asda2','5ggh']    
    estado = ['matriculado','suspendido','becado','egresado','posgrado']
    
    #Generar 3 series (3 columnas que constituirán el dataframe)
    serieNombres = pd.Series( [ random.choice(nombres) for _ in range(numeroEstudiantes)] )
    seriePuntajes = pd.Series( [ random.randint(100,200) for _ in range(numeroEstudiantes) ] )
    serieEstados = pd.Series( [random.choice(estado) for _ in range(numeroEstudiantes)] )
    
    #Visualizar las series
    print("******************************************")
    print(serieNombres)
    print(seriePuntajes)
    print(serieEstados)
    print("******************************************")
    
    #Preparar el diccionario que será convertido a Dataframe
    diccionario = {
        'Nombres':serieNombres,
        'Puntaje1':seriePuntajes
    }
    
    #Inicializar el dataframe con las dos columnas
    df = pd.DataFrame(diccionario)   
    
    #Adjuntar información al dataframe
    df['Codigo'] = codigos
    df['Estado'] = serieEstados  
    
    #Modificaciones del dataframe
    df.index.name = "Autonumérico"
    df.columns.name = "Estudiantes"
    df.set_index('Codigo',inplace=True)
    
    #Agregar nuevas columnas de puntajes
    seriePuntaje2 = pd.Series( [random.randint(100,200) for _ in range(numeroEstudiantes)], index=codigos )
    df['Puntaje2'] = seriePuntaje2
    seriePuntaje3 = pd.Series( [random.randint(100,200) for _ in range(numeroEstudiantes)], index=codigos )
    df['Puntaje3'] = seriePuntaje3
    
    #Reordenar las columnas del dataframe    
    df = df[ ['Nombres', 'Puntaje1', 'Puntaje2', 'Puntaje3','Estado'] ]
    
    #Calcular el promedio
    df['Promedio'] = round((df['Puntaje1'] + df['Puntaje2'] + df['Puntaje3'])/3, 2)  
    
    #Visualizar el dataframe que agrupó elementos de diferentes contenedores
    print("******************************************")
    print(df)
    print("******************************************") 
    
    #Generar archivo producto del dataframe
    df.to_csv('dfGenerado'+str(indice)+'.csv')
                  
    #Agrupaciones -> Cambia la cantidad de registros, se recomienda en un nuevo dataframe
    dfMedia = df.groupby(['Estado'])['Promedio'].mean() 
    
    #Agrupaciones para conteos y revisar proporciones
    dfConteo = df.groupby(['Estado'])[['Estado']].count()
    print(dfConteo)
    
    #Visualizar el dataframe que se obtiene al realizar agrupaciones
    print("******************************************")
    print(dfMedia)
    print("******************************************") 
    
    #Generar colección de colores
    conjuntoColores = {
                            'tab:blue',
                            'tab:orange',
                            'tab:green',
                            'tab:red',
                            'tab:purple',
                            'tab:brown',
                            'tab:pink',
                            'tab:gray',
                            'tab:olive',
                            'tab:cyan',
                          }    
    
    diccionarioColores = { estado[i]:list(conjuntoColores)[0] for i in range(len(estado)) }    
    print(diccionarioColores)
    # input()
    
    #Extensiones
    extensiones = ['pdf','svg','png']
    
    #Generar gráficos que luego serán manipulados por la administración del sistema
    dfMedia.plot(kind='barh')
    opciones = [
        'BarrasHorizontales'+str(indice)+'.'+random.choice(extensiones),
        './carpetaAlgo/BarrasHorizontales'+str(indice)+'.'+random.choice(extensiones)
    ]
    rutaBarras = random.choice(opciones)
    try:
        
        plt.savefig(rutaBarras,bbox_inches='tight')
    except:
        sys.stderr.write(f'Problemas generando las barras en la ruta {rutaBarras} \n')
    
    
    dfConteo.plot(kind='pie',y='Estado')   
    plt.savefig('Pastel'+str(indice)+'.'+random.choice(extensiones),bbox_inches='tight')
    
    #Mostrar plots en pantalla
    #plt.show()   
    


#Sección principal
iteraciones = random.randint(100,200)
for i in range(10):    
    generarBD(i)

    