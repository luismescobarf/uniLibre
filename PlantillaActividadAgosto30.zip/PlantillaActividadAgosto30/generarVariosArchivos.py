import random
import sys

numeroArchivos = sys.argv[1]
directorio = sys.argv[2]

#print("Entradas de la terminal -> ", numeroArchivos)

extensiones = ['.txt','.pdf','.png','.jpg']

prefijo = [	'listado',
			'carro',
			'estudiante',
			'lugar',
			'fichero'
]

sufijo = [
	'Temporal',
	'Inicial',
	'Definitivo'
]

for _ in range(int(numeroArchivos)):
	nombreArchivo = random.choice(prefijo) + random.choice(sufijo) + str(random.choice(list(range(0,100))))	+ random.choice(extensiones)
	
	print(nombreArchivo)
	with open(directorio+nombreArchivo, 'w') as f:
		numeroLineas = random.randint(7,200)
		numeroCaracteres = random.randint(10,40)
		contenido = ''
		for _ in range(numeroLineas):
			linea = str()
			for _ in range(numeroCaracteres):
				linea += random.choice('abcdefghijklmnopqrstuvwxyz .-;')
			contenido += linea
		f.write(contenido)
