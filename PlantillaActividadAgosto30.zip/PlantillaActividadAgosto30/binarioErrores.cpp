#include <iostream>
using namespace std;

int main(int argc, char *argv[]){

    //Validar el número de argumentos recibidos
    if(argc < 2){        
        cerr<<"No hay suficientes argumentos"<<"\n";
        cout<<"Esto debe ir en las salidas!!!"<<"\n";
    }else{
        //Presentar valor recibido
        cout<<"El valor recibido es: "<<argv[1]<<"\n";
    }


    //Salida sin errores
    return 69;

}
