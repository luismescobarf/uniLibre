import time
import sys

contador = int()
try:
	contador = int(sys.argv[1])
#except Exception as err:    
#    raise
#    print(f"Inesperado {err} , {type(err)}")
except ValueError:
    #print("Se presenta un error de conversión del primer parámetro!!!!")
    contador = 2
    print("Recuperando ejecución -> 2 ciclos")
    sys.stderr.write("-----------------------\n")
    sys.stderr.write("Se presenta un error de conversión del primer parámetro!!!!\n")
    sys.stderr.write("-----------------------\n")

i = int()
while i<contador:
    
    print(f"Salida {i}")
    print("durmiendo...")
    
    time.sleep(2)
    
    i = i+1
    
    
    
