import os

def child():
   print('\nUn nuevo hijo -> ',  os.getpid())
   os._exit(0)  

def parent():
   while True:
      newpid = os.fork()
      if newpid == 0:
         child()
      else:
         pids = (os.getpid(), newpid)
         print("padre: %d, hijo: %d\n" % pids)
      reply = input("q para salir / c para generar nuevo fork")
      if reply == 'c': 
          continue
      else:
          break

parent()